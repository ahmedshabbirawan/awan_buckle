'use strict';
document.addEventListener('DOMContentLoaded', function () {
  setTimeout(function () {
    floatchart();
  }, 500);
  if (!!document.querySelector('.feed-scroll')) {
    new SimpleBar(document.querySelector('.feed-scroll'));
  }
  if (!!document.querySelector('.pro-scroll')) {
    new SimpleBar(document.querySelector('.pro-scroll'));
  }
});


function floatchart() {
  // [ support-chart ] start
  (function () {
    var options1 = {
      chart: {
        type: 'area',
        height: 85,
        sparkline: {
          enabled: true
        }
      },
      colors: ["#1abc9c"],
      stroke: {
        curve: 'smooth',
        width: 2,
      },
      series: [{
        data: [0, 20, 10, 45, 30, 55, 20, 30, 0]
      }],
      tooltip: {
        fixed: {
          enabled: false
        },
        x: {
          show: false
        },
        y: {
          title: {
            formatter: function (seriesName) {
              return 'Ticket '
            }
          }
        },
        marker: {
          show: false
        }
      }
    }
    new ApexCharts(document.querySelector("#support-chart"), options1).render();
    var options2 = {
      chart: {
        type: 'bar',
        height: 85,
        sparkline: {
          enabled: true
        }
      },
      colors: ["#1abc9c"],
      plotOptions: {
        bar: {
          columnWidth: '70%'
        }
      },
      series: [{
        data: [25, 66, 41, 89, 63, 25, 44, 12, 36, 9, 54, 44, 12, 36, 9, 54, 25, 66, 41, 89, 63, 25, 44, 12, 36, 9, 25, 44, 12, 36, 9, 54]
      }],
      xaxis: {
        crosshairs: {
          width: 1
        },
      },
      tooltip: {
        fixed: {
          enabled: false
        },
        x: {
          show: false
        },
        y: {
          title: {
            formatter: function (seriesName) {
              return ''
            }
          }
        },
        marker: {
          show: false
        }
      }
    }
    new ApexCharts(document.querySelector("#support-chart1"), options2).render();
  })();
  // [ support-chart ] end
  // [ account-chart ] start

  (function () {
    var options = {
      chart: {
        height: 350,
        type: 'line',
        stacked: false,
      },
      stroke: {
        width: [0, 3],
        curve: 'smooth'
      },
      plotOptions: {
        bar: {
          columnWidth: '50%'
        }
      },
      colors: ['#1abc9c', '#c7d9ff'],
      series: [{
        name: 'Total Sales',
        type: 'column',
        data: [23, 11, 22, 27, 13, 22, 37, 21, 44, 22, 30]
      }, {
        name: 'Average',
        type: 'line',
        data: [30, 25, 36, 30, 45, 35, 64, 52, 59, 36, 39]
      }],
      fill: {
        opacity: [0.85, 1],
      },
      labels: ['01/01/2003', '02/01/2003', '03/01/2003', '04/01/2003', '05/01/2003', '06/01/2003', '07/01/2003', '08/01/2003', '09/01/2003', '10/01/2003', '11/01/2003'],
      markers: {
        size: 0
      },
      xaxis: {
        type: 'datetime'
      },
      yaxis: {
        min: 0
      },
      tooltip: {
        shared: true,
        intersect: false,
        y: {
          formatter: function (y) {
            if (typeof y !== "undefined") {
              return "$ " + y.toFixed(0);
            }
            return y;

          }
        }
      },
      legend: {
        labels: {
          useSeriesColors: true
        },
        markers: {
          customHTML: [
            function () {
              return ''
            },
            function () {
              return ''
            }
          ]
        }
      }
    }
    var chart = new ApexCharts(
      document.querySelector("#account-chart"),
      options
    );
    chart.render();
  })();

  // [ account-chart ] end
  // [ satisfaction-chart ] start
  (function () {
    var options = {
      chart: {
        height: 260,
        type: 'pie',
      },
      series: [66, 50, 40, 30],
      labels: ["extremely Satisfied", "Satisfied", "Poor", "Very Poor"],
      legend: {
        show: true,
        offsetY: 50,
      },
      dataLabels: {
        enabled: true,
        dropShadow: {
          enabled: false,
        }
      },
      theme: {
        monochrome: {
          enabled: true,
          color: '#1abc9c',
        }
      },
      responsive: [{
        breakpoint: 768,
        options: {
          chart: {
            height: 320,

          },
          legend: {
            position: 'bottom',
            offsetY: 0,
          }
        }
      }]
    }
    var chart = new ApexCharts(document.querySelector("#satisfaction-chart"), options);
    chart.render();
  })();
  // [ satisfaction-chart ] end
}